#!/usr/bin/env python3
"""
VPN用户管理API服务 - SQLite版本
提供VPN用户数据的查询、创建、更新、删除功能
支持JWT认证和数据加密传输
"""

import os
import sys
import sqlite3
import uuid
import secrets
import hashlib
import base64
import socket
import threading
import logging
from datetime import datetime, timedelta
from functools import wraps
from typing import Dict, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('/var/log/vpnapi/api.log', 'a'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('vpnapi')

# 检查必要的依赖
required_packages: Dict[str, Optional[Any]] = {}

try:
    import flask
    import flask_cors
import jwt
    import werkzeug.security
    
    # 所有依赖都已成功导入
    logger.info("所有必要的依赖已成功导入")
except ImportError as e:
    logger.error(f"缺少必要的依赖: {e}")
    logger.error("请安装依赖: pip install flask flask-cors pyjwt werkzeug")
    sys.exit(1)

from db_config import DatabaseConfig

# 创建Flask应用
app = flask.Flask(__name__)

def generate_password_hash(password):
    """生成scrypt格式的密码哈希"""
    salt = secrets.token_bytes(16)
    N = 16384  # CPU/内存开销参数
    r = 8      # 块大小参数
    p = 1      # 并行化参数
    dklen = 32 # 输出长度

    hash_bytes = hashlib.scrypt(
        password.encode(), 
        salt=salt, 
        n=N, 
        r=r, 
        p=p, 
        dklen=dklen
    )
    
    # 使用scrypt格式存储
    return f"scrypt:{N}:{r}:{p}:{dklen}:{base64.b64encode(salt).decode()}:{base64.b64encode(hash_bytes).decode()}"

def check_password_hash(stored_hash, plain_password):
    """验证密码哈希，支持多种格式，并返回是否需要升级
    
    Args:
        stored_hash: 存储的密码哈希
        plain_password: 明文密码
    
    Returns:
        tuple: (验证是否成功, 是否需要升级到新格式)
    """
    logger.debug(f"开始验证密码哈希，哈希格式: {stored_hash.split(':')[0] if ':' in stored_hash else 'unknown'}")
    
    # 检查是否是scrypt格式（当前标准）
    if stored_hash.startswith('scrypt:'):
        try:
            parts = stored_hash.split(':')
            if len(parts) != 7:
                logger.error("无效的scrypt哈希格式")
                return False, False
                
            N, r, p, dklen = map(int, parts[1:5])
            salt = base64.b64decode(parts[5])
            stored_hash_bytes = base64.b64decode(parts[6])
            
            # 使用相同参数生成哈希
            hash_bytes = hashlib.scrypt(
                plain_password.encode(), 
                salt=salt, 
                n=N, 
                r=r, 
                p=p, 
                dklen=dklen
            )
            
            # 使用安全的字符串比较
            is_valid = secrets.compare_digest(hash_bytes, stored_hash_bytes)
            logger.debug(f"scrypt验证结果: {'成功' if is_valid else '失败'}")
            return is_valid, False  # scrypt格式不需要升级
            
        except Exception as e:
            logger.error(f"scrypt哈希验证失败: {e}")
            return False, False
    
    # 检查是否是PBKDF2格式（需要升级）
        if stored_hash.startswith('pbkdf2:sha256:'):
        try:
            parts = stored_hash.split(':')
            if len(parts) >= 4:
                iterations = int(parts[2])
                salt = base64.b64decode(parts[3])
                stored_hash_part = parts[4] if len(parts) > 4 else ''
                
                # 使用相同参数生成哈希
                dk = hashlib.pbkdf2_hmac(
                    'sha256', 
                    plain_password.encode('utf-8'), 
                    salt, 
                    iterations
                )
                generated_hash = base64.b64encode(dk).decode('utf-8')
                
                is_valid = generated_hash == stored_hash_part
                logger.debug(f"PBKDF2验证结果: {'成功' if is_valid else '失败'}")
                return is_valid, is_valid  # 如果验证成功，标记需要升级
                
        except Exception as e:
            logger.error(f"PBKDF2哈希验证失败: {e}")
            return False, False
    
    # 尝试werkzeug格式（需要升级）
    try:
        is_valid = werkzeug.security.check_password_hash(stored_hash, plain_password)
        logger.debug(f"Werkzeug验证结果: {'成功' if is_valid else '失败'}")
        return is_valid, is_valid  # 如果验证成功，标记需要升级
    except Exception as e:
        logger.error(f"Werkzeug哈希验证失败: {e}")
        return False, False

def get_env_config():
    """获取环境配置"""
    env_file = "/home/pyuser/.vpnapi_env"
    config = {}
    
        try:
            with open(env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        value = value.strip('"').strip("'")
                    config[key] = value
                        print(f"Loaded env var: {key}")
        except Exception as e:
            print(f"Failed to load env file: {e}")
        raise
    
    return config

# 获取环境配置
env_config = get_env_config()

# Flask配置 - 从环境变量读取
app.config['SECRET_KEY'] = env_config['FLASK_SECRET_KEY']
app.config['JWT_SECRET_KEY'] = env_config['JWT_SECRET_KEY']
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)  # Token有效期24小时

# 启用CORS支持
flask_cors.CORS(app)

# 管理员认证配置 - 从环境变量读取
ADMIN_USERNAME = env_config['ADMIN_USERNAME']
ADMIN_PASSWORD_HASH = generate_password_hash(env_config['ADMIN_PASSWORD'])

# 获取数据库配置
DB_CONFIG = DatabaseConfig.get_sqlite_config()

def get_db():
    """获取SQLite数据库连接"""
    if 'db' not in flask.g:
        flask.g.db = sqlite3.connect(DB_CONFIG['database'])
        flask.g.db.row_factory = sqlite3.Row
    return flask.g.db

def close_db(e=None):
    """关闭数据库连接"""
    db = flask.g.pop('db', None)
    if db is not None:
        db.close()

@app.teardown_appcontext
def close_db_context(error):
    close_db()

def init_db():
    """Initialize database tables"""
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        
        # SQLite建表语句
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vpn_users (
                uuid TEXT PRIMARY KEY,
                user_name TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                c_name TEXT NOT NULL,
                c_email TEXT DEFAULT '',
                c_dep TEXT DEFAULT '',
                is_active INTEGER DEFAULT 1,
                is_qcuser INTEGER DEFAULT 0,
                create_date TEXT NOT NULL,
                update_date TEXT NOT NULL,
                expire_date TEXT DEFAULT '',
                note TEXT
            )
        ''')
        db.commit()
        print("Database tables initialized")

def token_required(f):
    """JWT令牌验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # 从请求头获取token
        if 'Authorization' in flask.request.headers:
            auth_header = flask.request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return flask.jsonify({'success': False, 'message': 'Token格式错误'}), 401
        
        if not token:
            return flask.jsonify({'success': False, 'message': '缺少访问令牌'}), 401
        
        try:
            data = jwt.decode(token, app.config['JWT_SECRET_KEY'], algorithms=['HS256'])
            current_user = data['username']
        except jwt.ExpiredSignatureError:
            return flask.jsonify({'success': False, 'message': '令牌已过期'}), 401
        except jwt.InvalidTokenError:
            return flask.jsonify({'success': False, 'message': '无效令牌'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

# ==================== 认证接口 ====================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """管理员登录"""
    try:
        data = flask.request.get_json()
        if not data:
            return flask.jsonify({
                'success': False, 
                'message': '请求数据格式错误'
            }), 400
            
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return flask.jsonify({
                'success': False, 
                'message': '用户名和密码不能为空'
            }), 400
        
        # 验证管理员凭据
        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            # 生成JWT token
            token = jwt.encode({
                'username': username,
                'exp': datetime.utcnow() + app.config['JWT_ACCESS_TOKEN_EXPIRES']
            }, app.config['JWT_SECRET_KEY'], algorithm='HS256')
            
            return flask.jsonify({
                'success': True,
                'message': '登录成功',
                'data': {
                    'access_token': token,
                    'token_type': 'Bearer',
                    'expires_in': int(app.config['JWT_ACCESS_TOKEN_EXPIRES'].total_seconds())
                }
            })
        else:
            return flask.jsonify({
                'success': False,
                'message': '用户名或密码错误'
            }), 401
            
    except Exception as e:
        return flask.jsonify({
            'success': False,
            'message': f'登录失败: {str(e)}'
        }), 500

# ==================== VPN用户管理接口 ====================

@app.route('/api/users', methods=['GET'])
@app.route('/api/vpn-configs/<config_uuid>/users', methods=['GET'])
@token_required
def get_users(current_user, config_uuid=None):
    """获取用户列表"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 构建查询
        query = "SELECT * FROM vpn_users"
        params = []
        
        # 如果指定了配置UUID，添加过滤条件
        if config_uuid:
            query += " WHERE config_uuid = ?"
            params.append(config_uuid)
            
        # 执行查询
        cursor.execute(query, params)
        users = cursor.fetchall()
        
        # 转换为字典列表
        user_list = []
        for user in users:
            user_dict = dict(user)
            user_dict.pop('password', None)  # 移除密码字段
            user_list.append(user_dict)
        
        return flask.jsonify({
            'success': True,
            'data': user_list
        })
        
    except Exception as e:
        return flask.jsonify({
            'success': False,
            'message': f'获取用户列表失败: {str(e)}'
        }), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/api/users/<user_uuid>', methods=['GET'])
@token_required
def get_user(current_user, user_uuid):
    """获取单个用户信息"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 查询用户
        cursor.execute('SELECT * FROM vpn_users WHERE uuid = ?', (user_uuid,))
        user = cursor.fetchone()
        
        if not user:
            return flask.jsonify({
                'success': False,
                'message': '用户不存在'
            }), 404
            
        # 转换为字典并移除敏感信息
        user_dict = dict(user)
        user_dict.pop('password', None)
        
        return flask.jsonify({
            'success': True,
            'data': user_dict
        })
            
    except Exception as e:
        return flask.jsonify({
            'success': False,
            'message': f'获取用户信息失败: {str(e)}'
        }), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/api/users', methods=['POST'])
@token_required
def create_user(current_user):
    """创建新用户"""
    db = None
    cursor = None
    try:
        data = flask.request.get_json()
        if not data:
            return flask.jsonify({
                'success': False, 
                'message': '请求数据格式错误'
            }), 400
        
        # 验证必需字段
        required_fields = ['username', 'password', 'email']
        for field in required_fields:
            if not data.get(field):
                return flask.jsonify({
                    'success': False,
                    'message': f'缺少必需字段: {field}'
                }), 400
        
        # 生成UUID
        user_uuid = str(uuid.uuid4())
        current_time = datetime.now().isoformat()
        
        # 生成密码哈希
        password_hash = generate_password_hash(data['password'])
        
        # 检查用户名是否已存在
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT uuid FROM vpn_users WHERE user_name = ?', (data['username'],))
        existing_user = cursor.fetchone()
        
        if existing_user:
            return flask.jsonify({
                'success': False,
                'message': '用户名已存在'
            }), 400
        
        # 插入新用户
        cursor.execute('''
            INSERT INTO vpn_users 
            (uuid, user_name, password, c_name, c_email, c_dep, is_active, is_qcuser, 
             create_date, update_date, expire_date, note)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_uuid,
            data['username'],
            password_hash,
            data['username'],
            data['email'],
            data.get('department', ''),
            1,  # is_active
            0,  # is_qcuser
            current_time,
            current_time,
            '',  # expire_date
            data.get('note', '')
        ))
            db.commit()
            
        return flask.jsonify({
                'success': True,
            'message': '用户创建成功',
            'data': {'uuid': user_uuid}
            }), 201
            
        except Exception as e:
            if db:
                db.rollback()
        return flask.jsonify({
                'success': False,
            'message': f'创建用户失败: {str(e)}'
            }), 500
        finally:
            if cursor:
                cursor.close()

@app.route('/api/vpn/auth', methods=['POST'])
def vpn_auth():
    """OpenVPN认证接口"""
    db = None
    cursor = None
    try:
        # 验证请求数据
        data = flask.request.get_json()
        if not data or not data.get('username') or not data.get('password'):
            logger.warning("认证请求数据无效")
            return flask.jsonify({'success': False}), 401

        username = data['username']
        password = data['password']
        
        logger.info(f"开始验证用户: {username}")

        # 获取数据库连接
        db = get_db()
        cursor = db.cursor()

        # 查询用户信息
        cursor.execute(
            "SELECT password, is_active FROM vpn_users WHERE user_name = ?",
            (username,)
        )
        user = cursor.fetchone()

        # 验证用户
        if not user:
            logger.warning(f"用户不存在: {username}")
            return flask.jsonify({'success': False}), 401
            
        if not user['is_active']:
            logger.warning(f"用户未激活: {username}")
            return flask.jsonify({'success': False}), 401
            
        # 验证密码并检查是否需要升级
        is_valid, need_upgrade = check_password_hash(user['password'], password)
        
        if not is_valid:
            logger.warning(f"密码验证失败: {username}")
            return flask.jsonify({'success': False}), 401
            
        # 如果需要升级密码哈希
        if need_upgrade:
            try:
                # 生成新的scrypt哈希
                new_hash = generate_password_hash(password)
                # 更新用户密码哈希
                cursor.execute(
                    'UPDATE vpn_users SET password = ? WHERE user_name = ?',
                    (new_hash, username)
                )
                db.commit()
                logger.info(f"已将用户 {username} 的密码哈希升级到scrypt格式")
    except Exception as e:
                logger.error(f"升级密码哈希失败: {str(e)}")
                # 注意：即使升级失败，仍然允许认证通过

        logger.info(f"用户认证成功: {username}")
        return flask.jsonify({'success': True}), 200

    except Exception as e:
        logger.error(f"VPN认证失败: {str(e)}")
        return flask.jsonify({'success': False}), 500

    finally:
        # 清理资源
        if cursor:
            cursor.close()
        if db:
            db.close()

@app.route('/api/users/<user_uuid>', methods=['PUT'])
@token_required
def update_user(current_user, user_uuid):
    """更新用户信息"""
    try:
        data = flask.request.get_json()
        if not data:
            return flask.jsonify({
                'success': False, 
                'message': '请求数据格式错误'
            }), 400
            
        db = get_db()
        cursor = db.cursor()
        
        # 检查用户是否存在
        cursor.execute('SELECT * FROM vpn_users WHERE uuid = ?', (user_uuid,))
        existing_user = cursor.fetchone()
        
        if not existing_user:
            return flask.jsonify({
                'success': False,
                'message': '用户不存在'
            }), 404
        
        # 构建更新字段
        update_fields = []
        params = []
        
        updateable_fields = ['c_name', 'c_email', 'c_dep', 'is_active', 'is_qcuser', 'expire_date', 'note']
        
        for field in updateable_fields:
            if field in data:
                update_fields.append(f"{field} = ?")
                params.append(data[field])
        
        # 特殊处理密码字段
        if 'password' in data and data['password']:
            update_fields.append("password = ?")
            params.append(generate_password_hash(data['password']))
        
        # 检查用户名更新（需要验证唯一性）
        if 'user_name' in data and data['user_name'] != existing_user['user_name']:
            cursor.execute(
                'SELECT uuid FROM vpn_users WHERE user_name = ? AND uuid != ?',
                (data['user_name'], user_uuid)
            )
            check_user = cursor.fetchone()
            
            if check_user:
                return flask.jsonify({
                    'success': False,
                    'message': '用户名已存在'
                }), 400
            
            update_fields.append("user_name = ?")
            params.append(data['user_name'])
        
        if not update_fields:
            return flask.jsonify({
                'success': False,
                'message': '没有要更新的字段'
            }), 400
        
        # 添加更新时间
        update_fields.append("update_date = ?")
        params.append(datetime.now().isoformat())
        
        # 执行更新
        params.append(user_uuid)
        update_query = f"UPDATE vpn_users SET {', '.join(update_fields)} WHERE uuid = ?"
        
        cursor.execute(update_query, params)
        db.commit()
        
        return flask.jsonify({
            'success': True,
            'message': '用户信息更新成功'
        })
        
    except Exception as e:
        if db:
            db.rollback()
        return flask.jsonify({
            'success': False,
            'message': f'更新用户失败: {str(e)}'
        }), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/api/users/<user_uuid>', methods=['DELETE'])
@token_required
def delete_user(current_user, user_uuid):
    """删除用户"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 检查用户是否存在
        cursor.execute('SELECT uuid FROM vpn_users WHERE uuid = ?', (user_uuid,))
        user = cursor.fetchone()
        
        if not user:
            return flask.jsonify({
                'success': False,
                'message': '用户不存在'
            }), 404
        
        # 删除用户
        cursor.execute('DELETE FROM vpn_users WHERE uuid = ?', (user_uuid,))
        db.commit()
        
        return flask.jsonify({
            'success': True,
            'message': '用户删除成功'
        })
        
    except Exception as e:
        if db:
            db.rollback()
        return flask.jsonify({
            'success': False,
            'message': f'删除用户失败: {str(e)}'
        }), 500
    finally:
        if cursor:
            cursor.close()

# ==================== 统计接口 ====================

@app.route('/api/stats', methods=['GET'])
@token_required
def get_stats(current_user):
    """获取统计信息"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 获取总用户数
        cursor.execute('SELECT COUNT(*) as total FROM vpn_users')
        total_users = cursor.fetchone()['total']
        
        # 获取活跃用户数
        cursor.execute('SELECT COUNT(*) as active FROM vpn_users WHERE is_active = 1')
        active_users = cursor.fetchone()['active']
        
        # 获取QC用户数
        cursor.execute('SELECT COUNT(*) as qc FROM vpn_users WHERE is_qcuser = 1')
        qc_users = cursor.fetchone()['qc']
        
        # 获取最近添加的用户
        cursor.execute('''
            SELECT uuid, user_name, c_name, create_date 
            FROM vpn_users 
            ORDER BY create_date DESC 
            LIMIT 5
        ''')
        recent_users = [dict(row) for row in cursor.fetchall()]
        
        # 获取即将过期的用户
        current_date = datetime.now().date()
        expiring_soon = current_date + timedelta(days=7)
        
        cursor.execute('''
            SELECT uuid, user_name, c_name, expire_date 
            FROM vpn_users 
            WHERE expire_date <= ? AND expire_date >= ?
            ORDER BY expire_date ASC
        ''', (expiring_soon.isoformat(), current_date.isoformat()))
        expiring_users = [dict(row) for row in cursor.fetchall()]
        
        return flask.jsonify({
            'success': True,
            'data': {
                'total_users': total_users,
                'active_users': active_users,
                'qc_users': qc_users,
                'recent_users': recent_users,
                'expiring_users': expiring_users
            }
        })
        
    except Exception as e:
        return flask.jsonify({
            'success': False,
            'message': f'获取统计信息失败: {str(e)}'
        }), 500
    finally:
        if cursor:
            cursor.close()

# ==================== 健康检查接口 ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    try:
        # 检查数据库连接
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT 1')
        cursor.fetchone()
        
        return flask.jsonify({
        'success': True,
            'message': 'Service is healthy',
        'timestamp': datetime.now().isoformat()
    })
    except Exception as e:
        return flask.jsonify({
            'success': False,
            'message': f'Service is unhealthy: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500
    finally:
        if cursor:
            cursor.close()

# ==================== OpenVPN认证接口 ====================

def verify_password_dual_format(plain_password, stored_hash):
    """验证密码（支持多种格式）并返回是否需要升级哈希格式
    
    Returns:
        tuple: (验证是否成功, 是否需要升级哈希)
    """
    # 首先尝试scrypt格式
    if stored_hash.startswith('scrypt:'):
        return check_scrypt_hash(plain_password, stored_hash), False
    
    # 然后尝试PBKDF2格式（注意处理可能包含$的情况）
    if stored_hash.startswith('pbkdf2:'):
        is_valid = check_password_hash(stored_hash, plain_password)
        return is_valid, is_valid  # 如果验证成功，标记需要升级
    
    # 最后尝试werkzeug格式
    try:
        from werkzeug.security import check_password_hash as werkzeug_check
        is_valid = werkzeug_check(stored_hash, plain_password)
        return is_valid, is_valid  # 如果验证成功，标记需要升级
    except Exception:
        return False, False

@app.route('/api/vpn/auth', methods=['POST'])
def vpn_authenticate():
    """VPN认证接口"""
    try:
        data = flask.request.get_json()
        if not data or not data.get('username') or not data.get('password'):
            return flask.jsonify({'success': False}), 401
            
        username = data['username']
        password = data['password']
        
        db = get_db()
        cursor = db.cursor()
        
        try:
            # 查询用户
        cursor.execute(
                'SELECT password, is_active FROM vpn_users WHERE user_name = ?',
            (username,)
        )
            user = cursor.fetchone()
            
            if not user:
                return flask.jsonify({'success': False}), 401
                
            if not user['is_active']:
                return flask.jsonify({'success': False}), 401
                
            # 验证密码（支持新旧格式）并检查是否需要升级
            is_valid, need_upgrade = verify_password_dual_format(password, user['password'])
            
            if not is_valid:
                return flask.jsonify({'success': False}), 401
                
            # 如果验证成功且需要升级哈希格式
            if need_upgrade:
                try:
                    # 生成新的scrypt哈希
                    new_hash = generate_scrypt_hash(password)
                    # 更新用户密码哈希
                    cursor.execute(
                        'UPDATE vpn_users SET password = ? WHERE user_name = ?',
                        (new_hash, username)
                    )
                    db.commit()
                    logger.info(f"已将用户 {username} 的密码哈希升级到scrypt格式")
    except Exception as e:
                    logger.error(f"升级密码哈希失败: {str(e)}")
                    # 注意：即使升级失败，仍然允许认证通过
                    
            return flask.jsonify({'success': True}), 200
                
        finally:
            if cursor:
                cursor.close()
            
    except Exception as e:
        logger.error(f"VPN认证失败: {str(e)}")
        return flask.jsonify({'success': False}), 500
    finally:
        if db:
            db.close()

def generate_scrypt_hash(password, N=16384, r=8, p=1, dklen=32):
    """生成scrypt密码哈希"""
    salt = secrets.token_bytes(16)
    hash_bytes = hashlib.scrypt(password.encode(), salt=salt, n=N, r=r, p=p, dklen=dklen)
    return f"scrypt:{N}:{r}:{p}:{dklen}:{base64.b64encode(salt).decode()}:{base64.b64encode(hash_bytes).decode()}"

def check_scrypt_hash(password, stored_hash):
    """验证scrypt密码哈希"""
    try:
        parts = stored_hash.split(':')
        if len(parts) != 7 or parts[0] != 'scrypt':
        return False

        N, r, p, dklen = map(int, parts[1:5])
        salt = base64.b64decode(parts[5])
        stored_hash_bytes = base64.b64decode(parts[6])
        
        hash_bytes = hashlib.scrypt(password.encode(), salt=salt, n=N, r=r, p=p, dklen=dklen)
        return secrets.compare_digest(hash_bytes, stored_hash_bytes)
        
    except Exception:
        return False

# ==================== 错误处理 ====================

@app.errorhandler(404)
def not_found(error):
    """404错误处理"""
    return flask.jsonify({
        'success': False,
        'message': '请求的资源不存在'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """500错误处理"""
    return flask.jsonify({
        'success': False,
        'message': '服务器内部错误'
    }), 500

# 用于Gunicorn的应用入口
def create_app():
    """创建应用实例"""
    print("Initializing VPN User Management API Service (SQLite version)...")
    
    # 初始化数据库
    init_db()
    
    print("API Service Configuration:")
    print(f"- Database Type: SQLite")
    print(f"- Database Path: {DB_CONFIG['database']}")
    print(f"- JWT Token Expiry: {app.config['JWT_ACCESS_TOKEN_EXPIRES']}")
    print(f"- Admin Username: {ADMIN_USERNAME}")
    print("- Admin Password: Loaded from environment variables")
    
    return app

# 初始化应用
app = create_app()

if __name__ == '__main__':
    print("Initializing VPN User Management API Service (SQLite version)...")
    
    # 初始化数据库
    init_db()
    
    print("API Service Configuration:")
    print(f"- Database Type: SQLite")
    print(f"- Database Path: {DB_CONFIG['database']}")
    print(f"- JWT Token Expiry: {app.config['JWT_ACCESS_TOKEN_EXPIRES']}")
    print(f"- Admin Username: {ADMIN_USERNAME}")
    print("- Admin Password: Loaded from environment variables")
    print("\nStarting service...")
    
    # 启动服务
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,  # 生产环境应设为False
        threaded=True
    ) 