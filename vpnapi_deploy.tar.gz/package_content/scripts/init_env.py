#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import uuid
import secrets
import string
import hashlib
import base64
from pathlib import Path
import argparse

def generate_password(length=16):
    """生成随机密码"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def generate_jwt_secret():
    """生成JWT密钥"""
    return base64.b64encode(secrets.token_bytes(32)).decode('utf-8')

def generate_flask_secret():
    """生成Flask密钥"""
    return secrets.token_hex(32)

def create_env_file(env_path):
    """创建环境配置文件"""
    admin_pass = generate_password()
    admin_pass_hash = hashlib.scrypt(
        admin_pass.encode(),
        salt=os.urandom(16),
        n=16384,
        r=8,
        p=1,
        dklen=32
    ).hex()
    
    env_content = f"""# API服务配置
API_HOST=unix:/dev/shm/vpnapi/vpnapi.socket
API_PORT=8000
API_WORKERS=4
API_TIMEOUT=120
API_LOG_LEVEL=INFO

# 数据库配置
DB_PATH=/home/pyuser/vpnapi/vpnapi.db

# JWT配置
JWT_SECRET_KEY={generate_jwt_secret()}
JWT_ACCESS_TOKEN_EXPIRES=86400

# Flask配置
FLASK_SECRET_KEY={generate_flask_secret()}
FLASK_ENV=production

# 管理员账号配置
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH={admin_pass_hash}

# 临时目录配置
TEMP_DIR=/dev/shm/via-file
SOCKET_DIR=/dev/shm/vpnapi
"""

    # 确保目录存在
    os.makedirs(os.path.dirname(env_path), exist_ok=True)
    
    # 写入配置文件
    with open(env_path, 'w') as f:
        f.write(env_content)
    
    # 设置文件权限
    os.chmod(env_path, 0o600)
    
    print(f"环境配置文件已创建：{env_path}")
    print(f"初始管理员密码：{admin_pass}")
    print("请妥善保存管理员密码，并在首次登录后修改！")

def main():
    parser = argparse.ArgumentParser(description='初始化API环境配置')
    parser.add_argument('--env-path', 
                      default='/home/pyuser/.vpnapi_env',
                      help='环境配置文件路径')
    
    args = parser.parse_args()
    
    try:
        create_env_file(args.env_path)
    except Exception as e:
        print(f"错误：{str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main() 