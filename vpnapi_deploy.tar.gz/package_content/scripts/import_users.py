#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import csv
import uuid
import sqlite3
import hashlib
import secrets
import string
import argparse
from datetime import datetime
from pathlib import Path

def generate_password(length=12):
    """生成随机密码"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def hash_password(password):
    """使用scrypt算法哈希密码"""
    salt = os.urandom(16)
    hash_value = hashlib.scrypt(
        password.encode(),
        salt=salt,
        n=16384,
        r=8,
        p=1,
        dklen=32
    )
    return hash_value.hex()

def get_username_from_email(email, db_conn):
    """从邮箱生成用户名，处理冲突"""
    base_username = email.split('@')[0]
    username = base_username
    counter = 1
    
    # 检查用户名是否已存在
    while True:
        cursor = db_conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        if cursor.fetchone()[0] == 0:
            break
        username = f"{base_username}{counter}"
        counter += 1
    
    return username

def import_users(csv_file, db_path):
    """导入用户数据"""
    if not os.path.exists(csv_file):
        print(f"错误：找不到CSV文件 {csv_file}", file=sys.stderr)
        sys.exit(1)

    # 连接数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 读取CSV文件
    imported = 0
    skipped = 0
    errors = []
    passwords = []

    try:
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            for row in reader:
                try:
                    # 验证必填字段
                    required_fields = ['c_name', 'c_email', 'c_dep', 'is_qcuser', 'expire_date']
                    if not all(row.get(field) for field in required_fields):
                        errors.append(f"行 {reader.line_num}: 缺少必填字段")
                        skipped += 1
                        continue

                    # 验证日期格式
                    try:
                        datetime.strptime(row['expire_date'], '%Y-%m-%d')
                    except ValueError:
                        errors.append(f"行 {reader.line_num}: 日期格式错误")
                        skipped += 1
                        continue

                    # 生成用户信息
                    username = get_username_from_email(row['c_email'], conn)
                    password = generate_password()
                    password_hash = hash_password(password)
                    user_uuid = str(uuid.uuid4())
                    is_qcuser = bool(int(row['is_qcuser']))

                    # 插入用户数据
                    cursor.execute("""
                        INSERT INTO users (
                            uuid, username, password_hash, c_name, c_email,
                            c_dep, is_qcuser, expire_date, note, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
                    """, (
                        user_uuid, username, password_hash, row['c_name'],
                        row['c_email'], row['c_dep'], is_qcuser,
                        row['expire_date'], row.get('note', ''),
                    ))

                    # 记录用户名和密码
                    passwords.append({
                        'username': username,
                        'password': password,
                        'email': row['c_email'],
                        'name': row['c_name']
                    })
                    imported += 1

                except Exception as e:
                    errors.append(f"行 {reader.line_num}: {str(e)}")
                    skipped += 1

        # 提交事务
        conn.commit()

        # 输出结果
        print(f"\n导入完成：")
        print(f"成功导入：{imported} 条")
        print(f"跳过记录：{skipped} 条")
        
        if errors:
            print("\n错误信息：")
            for error in errors:
                print(f"- {error}")

        # 生成密码文件
        if passwords:
            output_file = f"user_passwords_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("用户账号信息：\n")
                f.write("=" * 50 + "\n\n")
                for p in passwords:
                    f.write(f"姓名: {p['name']}\n")
                    f.write(f"邮箱: {p['email']}\n")
                    f.write(f"用户名: {p['username']}\n")
                    f.write(f"密码: {p['password']}\n")
                    f.write("-" * 30 + "\n")
            
            print(f"\n用户账号信息已保存到：{output_file}")
            # 设置文件权限
            os.chmod(output_file, 0o600)

    except Exception as e:
        print(f"错误：{str(e)}", file=sys.stderr)
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description='批量导入VPN用户')
    parser.add_argument('csv_file', help='用户数据CSV文件路径')
    parser.add_argument('--db-path', 
                      default='/home/pyuser/vpnapi/vpnapi.db',
                      help='数据库文件路径')
    
    args = parser.parse_args()
    import_users(args.csv_file, args.db_path)

if __name__ == '__main__':
    main() 