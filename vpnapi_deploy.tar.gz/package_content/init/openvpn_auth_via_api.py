#!/usr/bin/env python3
"""
OpenVPN认证程序 - 通过API认证用户
使用方法：
1. 将此文件复制到 /etc/openvpn/users/openvpn_auth_via_api.py
2. 在OpenVPN配置文件中添加：
   auth-user-pass-verify /etc/openvpn/users/openvpn_auth_via_api.py via-file
   script-security 2
"""

import os
import sys
import json
import urllib.request
import urllib.error
import ssl
import logging
from logging.handlers import RotatingFileHandler

# 配置日志
LOG_FILE = '/var/log/openvpn/auth.log'
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logger = logging.getLogger('vpn_auth')
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(LOG_FILE, maxBytes=1024*1024, backupCount=5)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# API配置
API_URL = 'https://localhost/api/vpn/auth'  # 使用nginx代理的HTTPS地址
VERIFY_SSL = False  # 如果使用自签名证书，设置为False

def auth_user(username, password):
    """通过API认证用户"""
    try:
        # 准备请求数据
        data = json.dumps({
            'username': username,
            'password': password
        }).encode('utf-8')
        
        # 创建请求
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'OpenVPN-Auth/1.0'
        }
        req = urllib.request.Request(API_URL, data=data, headers=headers)
        
        # 处理SSL验证
        context = None
        if not VERIFY_SSL:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        
        # 发送请求
        with urllib.request.urlopen(req, context=context) as response:
            result = json.loads(response.read().decode('utf-8'))
            
            if result.get('success'):
                logger.info(f'用户认证成功: {username}')
                return True
            else:
                logger.warning(f'用户认证失败: {username}')
                return False
                
    except urllib.error.HTTPError as e:
        logger.error(f'HTTP错误: {e.code} - {username}')
        return False
    except urllib.error.URLError as e:
        logger.error(f'URL错误: {e.reason} - {username}')
        return False
    except Exception as e:
        logger.error(f'认证异常: {str(e)} - {username}')
        return False

def main():
    """主函数"""
    try:
        # 检查参数
        if len(sys.argv) != 2:
            logger.error('参数错误：需要用户凭据文件路径')
            sys.exit(1)
            
        # 读取用户凭据文件
        creds_file = sys.argv[1]
        if not os.path.exists(creds_file):
            logger.error(f'凭据文件不存在: {creds_file}')
            sys.exit(1)
            
        with open(creds_file, 'r') as f:
            lines = f.readlines()
            
        if len(lines) < 2:
            logger.error('凭据文件格式错误')
            sys.exit(1)
            
        username = lines[0].strip()
        password = lines[1].strip()
        
        # 进行认证
        if auth_user(username, password):
            sys.exit(0)  # 认证成功
        else:
            sys.exit(1)  # 认证失败
            
    except Exception as e:
        logger.error(f'程序异常: {str(e)}')
        sys.exit(1)

if __name__ == '__main__':
    main() 