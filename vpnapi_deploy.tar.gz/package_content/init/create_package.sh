#!/bin/bash

# 设置版本号
VERSION="1.0.0"
PACKAGE_NAME="vpnapi_deploy"

# 确保在正确的目录
cd "$(dirname "$0")/.." || exit 1

# 创建临时目录用于打包
TEMP_DIR=$(mktemp -d)
mkdir -p "$TEMP_DIR/package_content"

# 复制文件到临时打包目录
cp -r requirements.txt scripts "$TEMP_DIR/package_content/"
mkdir -p "$TEMP_DIR/package_content/init"
cp init/* "$TEMP_DIR/package_content/init/"

# 创建部署包
cd "$TEMP_DIR" || exit 1
tar czf "${PACKAGE_NAME}-${VERSION}.tar.gz" package_content/

# 准备目标目录
TARGET_DIR="/tmp/openvpn_user_api"
rm -rf "$TARGET_DIR"
mkdir -p "$TARGET_DIR"

# 只复制三个必要文件到目标目录
cp "${PACKAGE_NAME}-${VERSION}.tar.gz" "$TARGET_DIR/vpnapi_deploy.tar.gz"
cp -f "$TEMP_DIR/package_content/init/README.md" "$TARGET_DIR/"
cp -f /home/pyuser/vpnapi/init_vpnapi.sh "$TARGET_DIR/"

# 设置正确的权限
chmod 644 "$TARGET_DIR/vpnapi_deploy.tar.gz"
chmod 644 "$TARGET_DIR/README.md"
chmod 755 "$TARGET_DIR/init_vpnapi.sh"

# 清理临时目录
rm -rf "$TEMP_DIR"

echo "部署包已准备完成，目标目录：$TARGET_DIR"
echo "文件列表："
ls -lh "$TARGET_DIR" 