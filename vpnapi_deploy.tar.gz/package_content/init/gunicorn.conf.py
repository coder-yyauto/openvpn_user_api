#!/usr/bin/env python3
"""
Gunicorn配置文件 - VPN API服务
使用中立的socket名称和环境变量文件
"""

import os
import multiprocessing

# 服务器配置
bind = "unix:/dev/shm/vpnapi/vpnapi.socket"
backlog = 2048

# 工作进程配置
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 50
preload_app = True

# 超时配置
timeout = 30
keepalive = 2
graceful_timeout = 30

# 日志配置
accesslog = "/home/pyuser/logs/api_access.log"
errorlog = "/home/pyuser/logs/api_error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# 进程配置 - 使用用户有权限的目录
pidfile = "/home/pyuser/vpnapi/vpnapi.pid"
user = "pyuser"
group = "pyuser"
tmp_upload_dir = None

# 安全配置
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190

def on_starting(server):
    """服务启动时的回调"""
    # 确保socket目录存在
    os.makedirs("/dev/shm/vpnapi", exist_ok=True)
    
    # 加载环境变量
    env_file = "/home/pyuser/.vpnapi_env"
    if os.path.exists(env_file):
        with open(env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key] = value

def on_exit(server):
    """服务退出时的回调"""
    # 清理socket文件
    socket_file = "/dev/shm/vpnapi/vpnapi.socket"
    if os.path.exists(socket_file):
        try:
            os.remove(socket_file)
        except:
            pass

# 进程命名
proc_name = "vpn_users_api"

# 后台运行设置（systemd管理时设为False）
daemon = False

# 工作进程启动后钩子
def when_ready(server):
    """Service ready hook function"""
    print(f"VPN User Management API Service started, listening on: {bind}")
    print(f"Worker processes: {workers}")

# 工作进程退出钩子
def worker_int(worker):
    """Worker interrupt hook"""
    print(f"Worker {worker.pid} received interrupt signal")

def post_fork(server, worker):
    """Worker fork hook"""
    print(f"Worker {worker.pid} started") 