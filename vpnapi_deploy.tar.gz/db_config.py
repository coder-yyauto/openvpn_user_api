#!/usr/bin/env python3
"""
数据库配置管理
支持MySQL和SQLite数据库切换
从环境变量读取敏感信息
"""

import os

class DatabaseConfig:
    """数据库配置类"""
    
    @classmethod
    def _get_env_var(cls, var_name, default=None, required=True):
        """安全获取环境变量"""
        value = os.environ.get(var_name, default)
        if required and value is None:
            raise ValueError(f"环境变量 {var_name} 未设置")
        return value
    
    @classmethod
    def get_mysql_config(cls):
        """获取MySQL配置 - 从环境变量读取"""
        try:
            return {
                'host': cls._get_env_var('DB_HOST'),
                'port': int(cls._get_env_var('DB_PORT', '3306', False) or '3306'),
                'user': cls._get_env_var('DB_USER'),
                'password': cls._get_env_var('DB_PASSWORD'),
                'database': cls._get_env_var('DB_NAME'),
                'charset': 'utf8mb4',
                'autocommit': True
            }
        except ValueError as e:
            # 如果环境变量未设置，使用硬编码配置作为后备（兼容性）
            print(f"警告: {e}, 使用默认配置")
            return {
                'host': 'rm-uf6wd0ynewkt75yc0.mysql.rds.aliyuncs.com',
                'port': 3306,
                'user': 'uvpn4jr',
                'password': '11f*nga2Fpr',
                'database': 'uvpn4jr',
                'charset': 'utf8mb4',
                'autocommit': True
            }
    
    # SQLite配置 (主数据库)
    SQLITE_CONFIG = {
        'database': '/home/pyuser/vpnapi/data/psw.db'
    }
    
    # 当前使用的数据库类型
    CURRENT_DB_TYPE = 'sqlite'  # 'mysql' 或 'sqlite'
    
    @classmethod
    def get_sqlite_config(cls):
        """获取SQLite配置"""
        return cls.SQLITE_CONFIG.copy()
    
    @classmethod
    def get_current_db_type(cls):
        """获取当前数据库类型"""
        return cls.CURRENT_DB_TYPE
    
    @classmethod
    def set_db_type(cls, db_type):
        """设置数据库类型"""
        if db_type in ['mysql', 'sqlite']:
            cls.CURRENT_DB_TYPE = db_type
        else:
            raise ValueError("数据库类型必须是 'mysql' 或 'sqlite'")

if __name__ == "__main__":
    print("=== 数据库配置信息 ===")
    print(f"当前数据库类型: {DatabaseConfig.get_current_db_type()}")
    mysql_config = DatabaseConfig.get_mysql_config()
    # 不显示敏感信息
    safe_config = mysql_config.copy()
    safe_config['password'] = '***'
    print("MySQL配置:", safe_config)
    print("SQLite配置:", DatabaseConfig.get_sqlite_config()) 