#!/usr/bin/env python3
import sqlite3
import uuid
from datetime import datetime
import os
import secrets
import hashlib
import base64

def generate_password_hash(password):
    """生成PBKDF2格式的密码哈希"""
    salt = secrets.token_bytes(16)
    iterations = 10000
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
    salt_b64 = base64.b64encode(salt).decode('utf-8')
    hash_b64 = base64.b64encode(dk).decode('utf-8')
    return f"pbkdf2:sha256:{iterations}:{salt_b64}:{hash_b64}"

def add_user(username, password):
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'psw.db')
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 生成用户数据
    user_data = {
        'uuid': str(uuid.uuid4()),
        'username': username,
        'password_hash': generate_password_hash(password),
        'create_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'update_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    try:
        # 插入用户数据
        cursor.execute('''
            INSERT INTO vpn_users (
                uuid, user_name, password, c_name, create_date, update_date, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, 1)
        ''', (
            user_data['uuid'],
            user_data['username'],
            user_data['password_hash'],
            user_data['username'],  # 使用用户名作为显示名
            user_data['create_date'],
            user_data['update_date']
        ))
        conn.commit()
        print(f"成功添加用户: {username}")
        return True
    except sqlite3.IntegrityError:
        print(f"用户已存在: {username}")
        return False
    except Exception as e:
        print(f"添加用户失败: {e}")
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    add_user("heyan", "heyan123") 